with Ada.Command_Line;
with Ada.Text_IO;

procedure Echo_Arguments is
begin
   for I in 1 .. Ada.Command_Line.Argument_Count loop
      Ada.Text_IO.Put ("'");
      declare
         Argument : constant String := Ada.Command_Line.Argument (I);
      begin
         for J in Argument'Range loop
            Ada.Text_IO.Put (
              (case Argument (J) is
                when ''' => "\'",
                when '\' => "\\",
                when others => "" & Argument (J)));
         end loop;
      end;
      Ada.Text_IO.Put_Line ("'");
   end loop;
end Echo_Arguments;
